# OpenSignals-with-Sounds
Contentpack for the Opensignalsmod but all moving parts have sound 

Update Log:

Version 0.1 : 

- Sounds for GSM-R
- Sounds for ETCS (provided by the EU-Norm)
- Sounds for the Switching Motor (provided by the EU-Norm)